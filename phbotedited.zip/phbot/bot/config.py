class Config(object):
    LOGGER = True

    #REQUIRED
    API_KEY = "5237975276:AAFUie7e9j6NJVHo5I8cZM6NL3daM8YE8NY"
    OWNER_ID = 5286028922
    BOT_URL = "https://t.me/dNdauto_bot"
    OWNER_USERNAME = "X_AK_R"

    #COINPAYMENTS INFO
    PUBLIC_KEY = "f71224f423c6e368b8f415cd6983f1706ece72f91d243c430209f67265b9e0d4"
    PRIVATE_KEY = "f8059fc4df70b77A9f7CB57b0259e3E0F18f149BcC887ad2E9359591ace05EB1"

    #IPN_SECRET = ""
    IPN_URL = "https://telegram.com"
    MIN_DEPOSIT = 20

    same = "/root/phbot/bot/database"

    #IMAGE WATERMARK TEXT
    WATERMARk_IMAGE = f"{same}/images/dndstore.png"
    SOLD = f"{same}/images/sold.png"

    #DB FILES
    SELLER_FILE = f"{same}/sellers.json"
    SHOP_FILE = f"{same}/shop.json"
    USERS_FILE = f"{same}/users.json"
    CHANNEL_FILE = f"{same}/channels.json"
    IMAGE_FOLDER = f"{same}/images"
    
    LOAD = []

    #OPTIONAL
    WORKERS = 8  # Number of subthreads to use. This is the recommended amount - see for yourself what works best!
    ALLOW_EXCL = False  # Allow ! commands as well as /


class Production(Config):
    LOGGER = False


class Development(Config):
    LOGGER = True