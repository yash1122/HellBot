import logging
import os
import sys
import telegram.ext as tg
from bot.config import Development as Config

# enable logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO)

LOGGER = logging.getLogger(__name__)

# if version < 3.9, stop bot.
#if sys.version_info[0] < 3 or sys.version_info[1] < 9:
#    LOGGER.error("You MUST have a python version of at least 3.6! Multiple features depend on this. Bot quitting.")
#    quit(1)



TOKEN = Config.API_KEY
# try:
#     OWNER_ID = Config.OWNER_IDS
# except ValueError:
#     raise Exception("Your OWNER_ID variable is not a valid integer.")

# try:
#     SUDO_USERS = set(int(x) for x in Config.SUDO_USERS or [])
# except ValueError:
#     raise Exception("Your sudo users list does not contain valid integers.")

LOAD = Config.LOAD
WORKERS = Config.WORKERS


# SUDO_USERS.add(OWNER_ID)

updater = tg.Updater(TOKEN, workers=WORKERS)

dispatcher = updater.dispatcher

# SUDO_USERS = list(SUDO_USERS)
