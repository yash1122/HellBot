from telegram import Update, Bot
from telegram import ParseMode
from telegram.ext import CommandHandler, run_async, MessageHandler, Filters
from bot.config import Development as Config
from bot import dispatcher


@run_async
def support(bot: Bot, update: Update):
    update.effective_message.reply_text(f"Contact @{Config.OWNER_USERNAME}, for any query or support.", parse_mode=ParseMode.HTML)

__mod_name__ = "support"

dispatcher.add_handler(MessageHandler(Filters.regex('Support 🆘') & ~Filters.command, support))
TOS_HANDLER = CommandHandler("support", support)
dispatcher.add_handler(TOS_HANDLER)