from telegram import Update, Bot, InlineKeyboardMarkup, InlineKeyboardButton, ParseMode
from telegram.ext import CommandHandler, CommandHandler, MessageHandler, Filters, run_async
import json
from bot import dispatcher, LOGGER
from bot.config import Development as Config
import random
from PIL import Image
import time
import base64
from random import randint



@run_async
def add(bot: Bot, update: Update):
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    userid = update.effective_user.id
    if str(userid) in shx.keys():
        bot.send_message(chat_id=userid, text=f"Please send the product to be added!")

def adder(bot: Bot, update: Update):
    fchnl = open(Config.CHANNEL_FILE)
    channels = json.load(fchnl)
    fchnl.close()
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    try:
        userid = update.effective_user.id
        username = update.effective_user.username
        if str(userid) in shx.keys():
            update.message.reply_text(text=f"Please standby adding the product...")
            addx = update.message.caption
            if "==" in addx:
                photofl = ''
                try:
                    photo_file = update.message.photo[-1].get_file()
                    photo_name = f'{random.randint(111111111, 999999999999)}.jpg'
                    photo_file.download(Config.IMAGE_FOLDER  + '/' +  photo_name)
                    time.sleep(4)
                    im = Image.open(Config.IMAGE_FOLDER + '/' + photo_name)
                    im2 = Image.open(Config.WATERMARk_IMAGE)
                    newsize = (1000, 1000)
                    im2 = im2.resize(newsize)
                    width, height = im.size
                    width2, height2 = im2.size
                    im.paste(im2, (int((width/2)-width2/2),int((height/2)-height2/2)), mask = im2)
                    im.save(Config.IMAGE_FOLDER  + '/' +  photo_name)
                    photofl = Config.IMAGE_FOLDER  + '/' +  photo_name
                except Exception as e:
                    LOGGER.error(e)
                    pass
                addxx = addx.split("\n==\n")
                item = addxx[0]
                key = addxx[1]
                prod = addxx[2]
                info = addxx[3]
                cred = addxx[4]
                price = prod.split(": ")
                price = price[1]
                fshop = open(Config.SHOP_FILE)
                fchnl = open(Config.CHANNEL_FILE)
                shop = json.load(fshop)
                channels = json.load(fchnl)
                fshop.close()
                fchnl.close()
                idx = randint(10000, 999999)
                update.message.reply_text(text=f"Added succesfully!")
                message = prod + "-" + key + "-" + item
                message_bytes = message.encode('ascii')
                bs64 = base64.b64encode(message_bytes).decode("utf-8")
                addcmd = {prod: {"id": idx, "link": f"{Config.BOT_URL}?start={bs64}", "img": photofl, "info": info, "cred": cred, "seller": {"userid": userid, "username": username}}}
                bck = {"< Back": ""}
                with open(Config.SHOP_FILE, "r+") as fl:
                    sh = json.load(fl)
                    kh = sh[item][key]
                    kh.pop("< Back")
                    kh.update(addcmd)
                    kh.update(bck)
                    fl.seek(0)
                    json.dump(sh, fl, indent=4)
                    fl.close()
                    fshop = open(Config.SHOP_FILE)
                    shop = json.load(fshop)
                    fshop.close()
                btnsx = [
                    [InlineKeyboardButton("BUY via bot", callback_data=str(prod + ":" + key + ":" + item), url=f"{Config.BOT_URL}?start={bs64}")],
                    [InlineKeyboardButton("Contact seller to buy", url=f"https://t.me/{Config.OWNER_USERNAME}")]
                ]
                promo = f"ID: {idx}\n--------\n{item} | {key}\n--------\n{prod}\n--------\n{info}\n--------\nPrice: {price}"
                bot.send_message(chat_id=Config.OWNER_ID, text=f"Added Porduct:\nID: {idx}\n{prod}\n{info}\Seller:{userid} (@{username})")
                for chnl in channels:
                    try:
                        bot.send_photo(chat_id=chnl, photo=open(photofl, 'rb'), caption=promo, parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup((btnsx)))
                    except Exception as e:
                        LOGGER.error(e)
                        pass
                update.message.reply_text(text=f"Posted in channels succesfully!")
    except Exception as e:
        LOGGER.error(e)
        pass


__mod_name__ = "add"

WALLET_HANDLER = CommandHandler("add", add)
dispatcher.add_handler(MessageHandler(Filters.photo & ~Filters.command, adder))
dispatcher.add_handler(WALLET_HANDLER)