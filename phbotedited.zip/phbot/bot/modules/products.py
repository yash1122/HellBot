from telegram import Update, Bot
from telegram import ParseMode
from telegram.ext import CommandHandler, run_async, MessageHandler, Filters
import json
from bot.config import Development as Config
from bot import LOGGER, dispatcher


@run_async
def products(bot: Bot, update: Update):
    sfilex = open(Config.SHOP_FILE)
    sjson = json.load(sfilex)
    sfilex.close()
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    userid = update.effective_user.id
    if userid == Config.OWNER_ID:
        res = ''
        try:
            for citm in sjson:
                for cprd1 in sjson[citm]['Checking/savings']:
                    if cprd1 != "< Back":
                        res += f"\nID: {sjson[citm]['Checking/savings'][cprd1]['id']} | {cprd1} by {sjson[citm]['Checking/savings'][cprd1]['seller']['userid']} (@{sjson[citm]['Checking/savings'][cprd1]['seller']['username']})"
                for cprd2 in sjson[citm]['Credit']:
                    if cprd2 != "< Back":
                        res += f"\nID: {sjson[citm]['Credit'][cprd2]['id']} | {cprd2} by {sjson[citm]['Credit'][cprd2]['seller']['userid']} (@{sjson[citm]['Credit'][cprd2]['seller']['username']})"
                for cprd3 in sjson[citm]['Debit+pin']:
                    if cprd3 != "< Back":
                        res += f"\nID: {sjson[citm]['Debit+pin'][cprd3]['id']} | {cprd3} by {sjson[citm]['Debit+pin'][cprd3]['seller']['userid']} (@{sjson[citm]['Debit+pin'][cprd3]['seller']['username']})"
            if res == '':
                update.effective_message.reply_text(f"No products to be shown!", parse_mode=ParseMode.HTML)
            else:
                update.effective_message.reply_text(f"Products list by sellers:\n{res}", parse_mode=ParseMode.HTML)
        except Exception as e:
            LOGGER.error(e)
            pass
    elif str(userid) in shx.keys():
        res = ''
        try:
            for citm in sjson:
                for cprd1 in sjson[citm]['Checking/savings']:
                    if cprd1 != "< Back" and userid == sjson[citm]['Checking/savings'][cprd1]['seller']['userid']:
                        res += f"\nID: {sjson[citm]['Checking/savings'][cprd1]['id']} | {cprd1} by {sjson[citm]['Checking/savings'][cprd1]['seller']['userid']} (@{sjson[citm]['Checking/savings'][cprd1]['seller']['username']})"
                for cprd2 in sjson[citm]['Credit']:
                    if cprd2 != "< Back" and userid == sjson[citm]['Credit'][cprd2]['seller']['userid']:
                        res += f"\nID: {sjson[citm]['Credit'][cprd2]['id']} | {cprd2} by {sjson[citm]['Credit'][cprd2]['seller']['userid']} (@{sjson[citm]['Credit'][cprd2]['seller']['username']})"
                for cprd3 in sjson[citm]['Debit+pin']:
                    if cprd3 != "< Back" and userid == sjson[citm]['Debit+pin'][cprd2]['seller']['userid']:
                        res += f"\nID: {sjson[citm]['Debit+pin'][cprd3]['id']} | {cprd3} by {sjson[citm]['Debit+pin'][cprd3]['seller']['userid']} (@{sjson[citm]['Debit+pin'][cprd3]['seller']['username']})"
            if res == '':
                update.effective_message.reply_text(f"No products to be shown!", parse_mode=ParseMode.HTML)
            else:
                update.effective_message.reply_text(f"Products by sellers:\n{res}", parse_mode=ParseMode.HTML)
        except Exception as e:
            LOGGER.error(e)
            pass
    else:
        update.effective_message.reply_text(f"lwd hai", parse_mode=ParseMode.HTML)


__mod_name__ = "products"

dispatcher.add_handler(MessageHandler(Filters.regex('Products 🗂') & ~Filters.command, products))
PRODUCT_HANDLER = CommandHandler("products", products)
dispatcher.add_handler(PRODUCT_HANDLER)