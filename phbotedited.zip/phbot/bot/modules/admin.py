from telegram import Update, Bot
from telegram import ParseMode
from telegram.ext import CommandHandler, run_async, CallbackQueryHandler, MessageHandler, Filters
from bot.config import Development as Config
import json
from bot import LOGGER, dispatcher



@run_async
def admin(bot: Bot, update: Update):
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    userid = update.effective_user.id
    if str(userid) in shx.keys():
        admin_text = f"Welcome to admin panel\nAdmin commands\n\n/stats: To know the stats\n\n/add: To add products to shop(make sure to use the format)\n(ex: \nBOA\n==\nCredit\n==\nproduct: 900$\n==\nproduct info\n==\ncredentials)\n\n/broadcast <message>: To broadcast message to every user\n\n/add_channel <channel id>: To add a new channel id to databse"
        update.effective_message.reply_text(admin_text)

__mod_name__ = "admin"

dispatcher.add_handler(MessageHandler(Filters.regex('Admin 🔒') & ~Filters.command, admin))
ADMIN_HANDLER = CommandHandler("admin", admin)
dispatcher.add_handler(ADMIN_HANDLER)