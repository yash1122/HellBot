from telegram import Update, Bot
from telegram import ParseMode, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import CommandHandler, run_async, CallbackQueryHandler, MessageHandler, Filters
import json
from bot.config import Development as Config
from PIL import Image
from bot import dispatcher, LOGGER
import time

SHOP_TEXT = """
LIST OF BANKS
"""


@run_async
def shop(bot: Bot, update: Update):
    fshopx = open(Config.SHOP_FILE)
    shopx = json.load(fshopx)
    fshopx.close()
    update.message.reply_text(SHOP_TEXT, parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(item, callback_data=str(item))] for item in shopx])) #chase and stuff

def core(bot: Bot, update: Update):
    fshopx = open(Config.SHOP_FILE)
    fusr = open(Config.USERS_FILE)
    shopx = json.load(fshopx)
    wallet = json.load(fusr)
    fshopx.close()
    fusr.close()
    fchnl = open(Config.CHANNEL_FILE)
    channels = json.load(fchnl)
    fchnl.close()
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()

    query = update.callback_query
    query.answer()
    userid = update.effective_user.id
    itemx = query.data
    
    if "|" in itemx and "Back" not in itemx: # to sell stuff
        fshopx = open(Config.SHOP_FILE)
        shopx = json.load(fshopx)
        fshopx.close()
        itemx = itemx.split("|")
        keyx = itemx[0]
        itemx = itemx[1]
        if shopx[itemx][keyx] == {"< Back": ""}:
            text = "List is empty"
            query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(([[InlineKeyboardButton(smth, callback_data=str(smth + ":" + keyx + ":" + itemx))] for smth in shopx[itemx][keyx]]))) #keyerror but back button
            pass
        else:
            text = keyx + " List for sale"
            query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(([[InlineKeyboardButton(smth, callback_data=str(smth + ":" + keyx + ":" + itemx))] for smth in shopx[itemx][keyx]]))) #to sell stuffs 300$

    elif ":" in itemx and "Back" not in itemx: #product page
        fshopx = open(Config.SHOP_FILE)
        shopx = json.load(fshopx)
        fshopx.close()
        itemxx = itemx.split(":")
        prod = itemxx[0]
        price = itemxx[1].strip(" ")
        kx = itemxx[2]
        itm = itemxx[3]
        prevmsg = update.effective_message.message_id
        format = shopx[itm][kx][prod + ": " + price]['info'] + "\n--------\nPrice: " + price
        imgfile = shopx[itm][kx][prod + ": " + price]['img']
        todel = bot.send_photo(chat_id=userid, photo=open(imgfile, 'rb')).message_id
        btns = [
            [InlineKeyboardButton("BUY (Wallet/Automactic)", callback_data=str("BUY" + "!" + itm + "!" + kx + "!" + prod + "!" + price + "!" + str(todel)))],
            [InlineKeyboardButton("Contact to buy", callback_data=str("BUYcontact" + "!" + itm + "!" + kx + "!" + prod + "!" + price + "!" + str(todel)))],
            [InlineKeyboardButton("< Back", callback_data=str("Back" + "#" + kx + "#" + itm + "#" + str(todel)))]
        ]
        bot.delete_message(chat_id=userid, message_id=prevmsg)
        bot.send_message(chat_id=userid, text=format, reply_markup=InlineKeyboardMarkup((btns))) #buy bro
        if userid == Config.OWNER_ID or str(userid) in shx.keys() and userid == shopx[itm][kx][prod + ": " + price]['seller']['userid']:
            btnsx = [
            [InlineKeyboardButton("Repost", callback_data=str("Repost" + "^" + itm + "^" + kx + "^" + prod + "^" + price + "^"))],
            [InlineKeyboardButton("Delete", callback_data=str("Delete" + "^" + itm + "^" + kx + "^" + prod + "^" + price + "^" ))]
        ]
            bot.send_message(chat_id=userid, text="Admin Commands", reply_markup=InlineKeyboardMarkup((btnsx)))
            # time.sleep(8)
            # bot.delete_message(chat_id=userid, message_id=tdl)

    elif "^" in itemx and "Back" not in itemx:
        fshopx = open(Config.SHOP_FILE)
        shopx = json.load(fshopx)
        fshopx.close()
        itemx = itemx.split("^")
        chck = itemx[0]
        itm = itemx[1]
        kx = itemx[2]
        prod = itemx[3]
        price = itemx[4]
        prod = f"{prod}: {price}"
        if chck == "Repost":
            idxx = shopx[itm][kx][prod]['id']
            info = shopx[itm][kx][prod]['info']
            photofl = shopx[itm][kx][prod]['img']
            link = shopx[itm][kx][prod]['link']
            btnsx = [
                    [InlineKeyboardButton("BUY via bot", callback_data=str(prod + ":" + kx + ":" + itm), url=link)],
                    [InlineKeyboardButton("Contact seller to buy", url=f"https://t.me/{Config.OWNER_USERNAME}")]
                ]
            promo = f"ID: {idxx}\n--------\n{itm} | {kx}\n--------\n{prod}\n--------\n{info}\n--------\nPrice: {price}"
            for chnl in channels:
                try:
                    bot.send_photo(chat_id=chnl, photo=open(photofl, 'rb'), caption=promo, parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup((btnsx)))
                except Exception as e:
                    LOGGER.error(e)
                    pass
            rp = query.edit_message_text("Reposted in every channel succesfully!").message_id
            time.sleep(3)
            bot.delete_message(chat_id=userid, message_id=rp)
        elif chck == "Delete":
            try:
                fshopx = open(Config.SHOP_FILE)
                shopx = json.load(fshopx)
                fshopx.close()
                with open(Config.SHOP_FILE, "w") as flx:
                    khx = shopx[itm][kx]
                    khx.pop(prod)
                    json.dump(shopx, flx, indent=4)
                    flx.close()
                    fshopx = open(Config.SHOP_FILE)
                    shopx = json.load(fshopx)
                    fshopx.close()
                    dl = query.edit_message_text("Pruduct deleted succesfully!").message_id
                    time.sleep(3)
                    bot.delete_message(chat_id=userid, message_id=dl)
            except Exception as e:
                LOGGER.error(e)
            
    elif "BUY" in itemx: #buy bro
        fusr = open(Config.USERS_FILE)
        wallet = json.load(fusr)
        fusr.close()
        userid = str(userid)
        itemx = itemx.split("!")
        cnct = itemx[0]
        itm = itemx[1]
        kx = itemx[2]
        prod = itemx[3]
        price = int(itemx[4].strip("$"))
        todelx = itemx[5]
        bot.delete_message(chat_id=userid, message_id=todelx)
        if "BUYcontact" in cnct:
            txt = f"Contact @{Config.OWNER_USERNAME} to buy lol"
            query.edit_message_text(txt)
        elif wallet[userid]['usd'] >= price and "BUYcontact" not in cnct:
            fshopx = open(Config.SHOP_FILE)
            fusr = open(Config.USERS_FILE)
            shopx = json.load(fshopx)
            wallet = json.load(fusr)
            fshopx.close()
            fusr.close()
            with open(Config.USERS_FILE, "w") as wfile:
                usd = wallet[userid]['usd']
                wallet[userid]['usd'] = usd - price
                json.dump(wallet, wfile, indent=4)
                wfile.close()
                fusr = open(Config.USERS_FILE)
                wallet = json.load(fusr)
                fusr.close()
            txt = shopx[itm][kx][prod + ": " + str(price) + "$"]['cred']
            idx = shopx[itm][kx][prod + ": " + str(price) + "$"]['id']
            sellerid = int(shopx[itm][kx][prod + ": " + str(price) + "$"]['seller']['userid'])
            photoflx = ''
            try:
                src = shopx[itm][kx][prod + ": " + str(price) + "$"]['img']
                im = Image.open(src)
                im2 = Image.open(Config.SOLD)
                newsize = (600, 600)
                im2 = im2.resize(newsize)
                width, height = im.size
                width2, height2 = im2.size
                im.paste(im2, (int((width/6)-width2/2),int((height/4.6)-height2/2)), mask = im2)
                im.save(src)
                photoflx = src
            except Exception as e:
                LOGGER.error(e)
                pass
            with open(Config.SHOP_FILE, "w") as flx:
                khx = shopx[itm][kx]
                khx.pop(prod + ": " + str(price) + "$")
                json.dump(shopx, flx, indent=4)
                flx.close()
                fshopx = open(Config.SHOP_FILE)
                shopx = json.load(fshopx)
                fshopx.close()
            query.edit_message_text(txt)
            sold = f"#SOLD ID: {idx}"
            for chnl in channels:
                try:
                    bot.send_photo(chat_id=chnl, photo=open(photoflx, 'rb'), caption=sold)
                except Exception as e:
                    LOGGER.error(e)
                    pass
            if sellerid == Config.OWNER_ID:
                bot.send_message(chat_id=Config.OWNER_ID, text=f'Sold ID: {idx} | {itm} | {kx} | {prod + ": " + str(price) + "$"}', parse_mode=ParseMode.MARKDOWN)
            else:
                bot.send_message(chat_id=Config.OWNER_ID, text=f'Sold ID: {idx} | {itm} | {kx} | {prod + ": " + str(price) + "$"}', parse_mode=ParseMode.MARKDOWN)
                bot.send_message(chat_id=sellerid, text=f'Sold ID: {idx} | {itm} | {kx} | {prod + ": " + str(price) + "$"}', parse_mode=ParseMode.MARKDOWN)

        else:
            txt = "You do not have enough funds, please go to wallet and add funds"
            query.edit_message_text(txt)

    elif "Back" in itemx: #back bro
        if ":" in itemx: #back to second shop page credit pin stuff
            fshopx = open(Config.SHOP_FILE)
            shopx = json.load(fshopx)
            fshopx.close()
            itemx = itemx.split(":")
            keyx = itemx[1]
            itemx = itemx[2]
            text = itemx + " List for sale"
            query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(([[InlineKeyboardButton(key, callback_data=str(key + "|" + itemx))] for key in shopx[itemx]])))
        elif "#" in itemx: #back to product page list
            fshopx = open(Config.SHOP_FILE)
            shopx = json.load(fshopx)
            fshopx.close()
            itemx = itemx.split("#")
            # if itemx[3]:
            todel = itemx[3]
            bot.delete_message(chat_id=userid, message_id=todel)
            keyx = itemx[1]
            itemx = itemx[2]
            text = keyx + " List for sale"
            query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(([[InlineKeyboardButton(smth, callback_data=str(smth + ":" + keyx + ":" + itemx))] for smth in shopx[itemx][keyx]]))) #to sell stuffs 300$
        else: #back to main shop page chase and stuff
            fshopx = open(Config.SHOP_FILE)
            shopx = json.load(fshopx)
            fshopx.close()
            query.edit_message_text(SHOP_TEXT, parse_mode=ParseMode.MARKDOWN, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(item, callback_data=str(item))] for item in shopx])) #chase and stuff

    else: #credit pins stuff
        fshopx = open(Config.SHOP_FILE)
        shopx = json.load(fshopx)
        fshopx.close()
        text = itemx + " List for sale"
        query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(([[InlineKeyboardButton(key, callback_data=str(key + "|" + itemx))] for key in shopx[itemx]]))).message_id #credit and pins stuff


__mod_name__ = "shop"

dispatcher.add_handler(MessageHandler(Filters.regex('Shop 🛒') & ~Filters.command, shop))
dispatcher.add_handler(CallbackQueryHandler(core))
SHOP_HANDLER = CommandHandler("shop", shop)
dispatcher.add_handler(SHOP_HANDLER)