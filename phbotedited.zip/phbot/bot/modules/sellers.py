from telegram import Update, Bot
from telegram import ParseMode
from telegram.ext import CommandHandler, run_async
from bot import dispatcher
from bot.config import Development as Config
import json

from bot import dispatcher

@run_async
def sellers(bot: Bot, update: Update):
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    userid = update.effective_user.id
    if userid == Config.OWNER_ID:
        sfile = open(Config.SELLER_FILE)
        sellers = json.load(sfile)
        sfile.close()
        res = ''
        for seller in sellers:
            res +=  f"{seller}\n"
        update.effective_message.reply_text(f"Sellers list:\n\n{res}", parse_mode=ParseMode.MARKDOWN)

__mod_name__ = "sellers"

SELLERS_HANDLER = CommandHandler("sellers", sellers)
dispatcher.add_handler(SELLERS_HANDLER)