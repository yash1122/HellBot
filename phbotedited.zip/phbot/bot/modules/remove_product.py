from telegram import Update, Bot
from telegram.ext import CommandHandler, run_async
from telegram import ParseMode
import json
from bot import dispatcher, LOGGER
from bot.config import Development as Config


@run_async
def remove_product(bot: Bot, update: Update):
    userid = update.effective_user.id
    if userid in Config.OWNER_IDS:
        sh = open(Config.SHOP_FILE)
        lsh = json.load(sh)
        sh.close()
        prod = update.message.text
        if prod != "/remove_product":
            prod = prod.replace('/remove_product ', '')
            prod = prod.split("(")
            item = prod[0]
            key = prod[1]
            prod = prod[2].strip("))")
            if item and key and prod:
                torem = lsh[item][key]
                if prod in torem.keys():
                    try:
                        with open(Config.CHANNEL_FILE, "r+") as shx:
                            shsx = json.load(shx)
                            pp = shsx[item][key]
                            pp.pop(prod)
                            shx.seek(0)
                            json.dump(shsx, shx, indent=4)
                            shx.close()
                            sh = open(Config.SHOP_FILE)
                            lsh = json.load(sh)
                            sh.close()
                    except Exception as e:
                        LOGGER.error(e)
                    update.message.reply_text("Removed successfully!", parse_mode=ParseMode.MARKDOWN)
                else:
                    update.message.reply_text("The product you want to remove doesn't exist!", parse_mode=ParseMode.MARKDOWN)
        else:
            update.message.reply_text("Wrong product remove format, please correct it and try again!", parse_mode=ParseMode.MARKDOWN)


__mod_name__ = "remove_product"

REMOVE_PRODUCT_HANDLER = CommandHandler("remove_product", remove_product)
dispatcher.add_handler(REMOVE_PRODUCT_HANDLER)