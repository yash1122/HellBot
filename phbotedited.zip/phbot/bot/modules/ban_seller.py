from telegram import Update, Bot
from telegram import ParseMode
from telegram.ext import CommandHandler, run_async, MessageHandler, Filters
from bot.config import Development as Config
import json
from bot import LOGGER, dispatcher


@run_async
def ban_seller(bot: Bot, update: Update):
    ch = open(Config.SELLER_FILE)
    lch = json.load(ch)
    ch.close()
    userid = update.effective_user.id
    if userid == Config.OWNER_ID:
        shid = update.message.text
        if shid != "/ban_seller":
            shid = shid.replace('/ban_seller ', '')
            if str(shid) in lch.keys():
                update.message.reply_text("Removing seller id from database...", parse_mode=ParseMode.MARKDOWN)
                try:
                    with open(Config.SELLER_FILE, "w") as chx:
                        lch.pop(str(shid))
                        json.dump(lch, chx, indent=4)
                        chx.close()
                        ch = open(Config.SELLER_FILE)
                        lch= json.load(ch)
                        ch.close()
                except Exception as ex:
                    LOGGER.error(ex)
                    pass
                update.message.reply_text("Seller banned successfully!", parse_mode=ParseMode.MARKDOWN)
            else:
                update.message.reply_text("Seller id not in database!", parse_mode=ParseMode.MARKDOWN)

__mod_name__ = "ban_seller"

BAN_SELLER_HANDLER = CommandHandler("ban_seller", ban_seller)
dispatcher.add_handler(BAN_SELLER_HANDLER)