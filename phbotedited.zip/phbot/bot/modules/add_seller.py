from telegram import Update, Bot
from telegram.ext import CommandHandler, run_async
from telegram import ParseMode
import json
from bot import dispatcher, LOGGER
from bot.config import Development as Config


@run_async
def add_seller(bot: Bot, update: Update):
    ch = open(Config.SELLER_FILE)
    lch= json.load(ch)
    ch.close()
    userid = update.effective_user.id
    if userid == Config.OWNER_ID:
        shid = update.message.text
        if shid != "/add_seller":
            shid = shid.replace('/add_seller ', '')
            if str(shid) not in lch.keys():
                update.message.reply_text("Adding seller id to database...", parse_mode=ParseMode.MARKDOWN)
                try:
                    appendshid = {str(shid): ""}
                    with open(Config.SELLER_FILE, "r+") as chx:
                        chsx = json.load(chx)
                        chsx.update(appendshid)
                        chx.seek(0)
                        json.dump(chsx, chx, indent=4)
                        chx.close()
                        ch = open(Config.SELLER_FILE)
                        lch= json.load(ch)
                        ch.close()
                except Exception as ex:
                    LOGGER.error(ex)
                update.message.reply_text("Added successfully!", parse_mode=ParseMode.MARKDOWN)
            else:
                update.message.reply_text("seller id already in database!", parse_mode=ParseMode.MARKDOWN)


__mod_name__ = "add_seller"

ADD_SELLER_HANDLER = CommandHandler("add_seller", add_seller)
dispatcher.add_handler(ADD_SELLER_HANDLER)