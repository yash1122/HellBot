from telegram import Update, Bot
from telegram.ext import CommandHandler, run_async
from telegram import ParseMode
import json
from bot import LOGGER, dispatcher
from bot.config import Development as Config



@run_async
def broadcast(bot: Bot, update: Update):
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    userid = update.effective_user.id
    if str(userid) in shx.keys():
        uf = open(Config.USERS_FILE)
        usersx = json.load(uf)
        uf.close()
        text = update.message.text
        if text != "/broadcast":
            text = text.replace('/broadcast ', '')
            for user in usersx:
                try:
                    bot.send_message(chat_id=user, text=text, parse_mode=ParseMode.MARKDOWN)
                except Exception as e:
                    LOGGER.error(e)
                    pass

__mod_name__ = "broadcast"

START_HANDLER = CommandHandler("broadcast", broadcast)
dispatcher.add_handler(START_HANDLER)