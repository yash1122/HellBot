from telegram import Update, Bot
from telegram.ext import CommandHandler, run_async, MessageHandler, Filters
from telegram import ParseMode, InlineKeyboardMarkup, InlineKeyboardButton
import json
from bot import dispatcher, LOGGER
from bot.config import Development as Config
import base64
import binascii
import telegram

def is_base64(s):
    try:
        base64.b64decode(s)
        return True
    except binascii.Error:
        return False

START_TEXT = """
DnD STORE PRESS THE BUTTONS TO SEE OPTION 

YOU WILL GET GOOD QUALITY LOGS HERE
"""

@run_async
def start(bot: Bot, update: Update):
    suf = open(Config.USERS_FILE)
    susers = json.load(suf)
    suf.close()
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    viewx = update.message.text
    viewx = viewx.strip("/start ")
    userid = update.effective_user.id
    if viewx == '':
        if str(userid) in shx.keys():
            custom_keyboard = [['Shop 🛒', 'Wallet 💸'], 
                    ['Support 🆘', 'Store Policy 📃'],
                    ['Admin 🔒', 'Products 🗂']]
            reply_markup = telegram.ReplyKeyboardMarkup(custom_keyboard, resize_keyboard=True)
            update.message.reply_text(START_TEXT, reply_markup=reply_markup)
        else:
            custom_keyboard = [['Shop 🛒', 'Wallet 💸'], 
                    ['Support 🆘', 'Store Policy 📃']]   
            reply_markup = telegram.ReplyKeyboardMarkup(custom_keyboard, resize_keyboard=True)
            update.message.reply_text(START_TEXT, reply_markup=reply_markup)
    suf = open(Config.USERS_FILE)
    susers = json.load(suf)
    suf.close()
    username = update.effective_user.username
    if str(userid) not in susers.keys():
        try:
            appendx = {str(userid): {"username": username, "usd": 0}}
            with open(Config.USERS_FILE, "r+") as filex:
                usx = json.load(filex)
                usx.update(appendx)
                filex.seek(0)
                json.dump(usx, filex, indent=4)
                filex.close()
                suf = open(Config.USERS_FILE)
                susers = json.load(suf)
                suf.close()
        except Exception as ex:
            LOGGER.error(ex)
    if is_base64(viewx) and viewx != '':
        fshopx = open(Config.SHOP_FILE)
        shopx = json.load(fshopx)
        fshopx.close()
        try:
            viewx = base64.b64decode(viewx).decode("utf-8")
            viewx = viewx.split("-")
            prodx = viewx[0].split(":")
            prod = prodx[0]
            price = prodx[1].strip(" ")
            kx = viewx[1]
            itm = viewx[2]
            format = shopx[itm][kx][prod + ": " + price]['info'] + "\n--------\nPrice: " + price
            imgfile = shopx[itm][kx][prod + ": " + price]['img']
            todel = bot.send_photo(chat_id=userid, photo=open(imgfile, 'rb')).message_id
            btns = [
                [InlineKeyboardButton("BUY (Wallet/Automactic)", callback_data=str("BUY" + "!" + itm + "!" + kx + "!" + prod + "!" + price + "!" + str(todel)))],
                [InlineKeyboardButton("Contact to buy", callback_data=str("BUYcontact" + "!" + itm + "!" + kx + "!" + prod + "!" + price + "!" + str(todel)))],
                [InlineKeyboardButton("< Back", callback_data=str("Back" + "#" + kx + "#" + itm + "#" + str(todel)))]
            ]
                
            bot.send_message(chat_id=userid, text=format, reply_markup=InlineKeyboardMarkup((btns))) #buy bro

        except:
            bot.send_message(chat_id=userid, text="Product sold!")



__mod_name__ = "start"

START_HANDLER = CommandHandler("start", start)
dispatcher.add_handler(START_HANDLER)