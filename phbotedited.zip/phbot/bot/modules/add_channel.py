from telegram import Update, Bot
from telegram.ext import CommandHandler, run_async
from telegram import ParseMode
import json
from bot import dispatcher, LOGGER
from bot.config import Development as Config


@run_async
def add_channel(bot: Bot, update: Update):
    ch = open(Config.CHANNEL_FILE)
    lch= json.load(ch)
    ch.close()
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    userid = update.effective_user.id
    if str(userid) in shx.keys():
        chid = update.message.text
        if chid != "/add_channel":
            chid = chid.replace('/add_channel ', '')
            if str(chid) not in lch.keys() and "-" in str(chid):
                update.message.reply_text("Adding channel id to database...", parse_mode=ParseMode.MARKDOWN)
                try:
                    appendchid = {str(chid): ""}
                    with open(Config.CHANNEL_FILE, "r+") as chx:
                        chsx = json.load(chx)
                        chsx.update(appendchid)
                        chx.seek(0)
                        json.dump(chsx, chx, indent=4)
                        chx.close()
                        ch = open(Config.CHANNEL_FILE)
                        lch= json.load(ch)
                        ch.close()
                except Exception as ex:
                    LOGGER.error(ex)
                update.message.reply_text("Added successfully!", parse_mode=ParseMode.MARKDOWN)
            else:
                update.message.reply_text("Channel id already in database!", parse_mode=ParseMode.MARKDOWN)


__mod_name__ = "add_channel"

ADD_CHANNEL_HANDLER = CommandHandler("add_channel", add_channel)
dispatcher.add_handler(ADD_CHANNEL_HANDLER)