from telegram import Update, Bot
from telegram import ParseMode
from telegram.ext import CommandHandler, run_async
from bot import dispatcher
from bot.config import Development as Config
import json

from bot import dispatcher

@run_async
def stats(bot: Bot, update: Update):
    sh = open(Config.SELLER_FILE)
    shx = json.load(sh)
    sh.close()
    userid = update.effective_user.id
    if str(userid) in shx.keys():
        cusf = open(Config.USERS_FILE)
        cusers = json.load(cusf)
        cusf.close()
        cshf = open(Config.SHOP_FILE)
        cshop = json.load(cshf)
        cshf.close()
        cchf = open(Config.CHANNEL_FILE)
        cchannel = json.load(cchf)
        cchf.close()

        count_user = 0
        count_channel = 0
        count_products = 0
        count_usd = 0
        back_count = 0

        for cusr in cusers:
            count_user += 1
            count_usd += cusers[cusr]['usd']

        for citm in cshop:
            for cprd1 in cshop[citm]['Checking/savings']:
                count_products += 1
            for cprd2 in cshop[citm]['Credit']:
                count_products += 1
            for cprd3 in cshop[citm]['Debit+pin']:
                count_products += 1
            back_count += 3
        
        count_products = count_products - back_count #subtract backs

        for chnl in cchannel:
            count_channel += 1
            
        stats_text = f"Statistics about bot\n\nTotal users(s): {count_user}\nTotal amount(s): {count_usd}$\nTotal product(s): {count_products}\nTotal Channel(s): {count_channel}"
        update.effective_message.reply_text(stats_text, parse_mode=ParseMode.MARKDOWN)

__mod_name__ = "stats"

STATS_HANDLER = CommandHandler("stats", stats)
dispatcher.add_handler(STATS_HANDLER)