import errno
from telegram import Update, Bot
from telegram.ext import CommandHandler, CommandHandler, MessageHandler, Filters, run_async
from telegram import ParseMode
import json
from bot import dispatcher, LOGGER
from bot.config import Development as Config
import threading
import time
import requests
import hmac
import hashlib
from collections import OrderedDict
from urllib.parse import urlencode

class CoinPaymentsAPI:
    api_url = 'https://www.coinpayments.net/api.php'
    api_version = 1

    def __init__(self, public_key=Config.PUBLIC_KEY, private_key=Config.PRIVATE_KEY):
        self.public_key = public_key
        self.private_key = private_key

    def _build_params(self, command, **kwargs):
        base_params = [('version', self.api_version),
                       ('key', self.public_key),
                       ('cmd', command),
                       ('format', 'json')]

        return urlencode(OrderedDict(base_params + sorted(kwargs.items())))

    def _build_signature(self, params):
        if not isinstance(params, bytes):
            params = bytearray(params, 'utf-8')

        byte_private_key = bytearray(self.private_key, 'utf-8')

        return hmac.new(byte_private_key, params, hashlib.sha512).hexdigest()

    def check_signature(self, data, signature):
        actual_signature = self._build_signature(data)

        return actual_signature == signature

    def send_api_request(self, command, **kwargs):
        params = self._build_params(command, **kwargs)
        signature = self._build_signature(params)
        headers = {'HMAC': signature,
                   'Content-Type': 'application/x-www-form-urlencoded'}

        return requests.post(self.api_url,
                             data=params,
                             headers=headers).json()

    def create_transaction(self, **kwargs):
        command = 'create_transaction'

        return self.send_api_request(command, **kwargs)
    
    def get_tx_info(self, **kwargs):
        command = 'get_tx_info'

        return self.send_api_request(command, **kwargs)




@run_async
def wallet(bot: Bot, update: Update):
    fwalx = open(Config.USERS_FILE)
    walletx = json.load(fwalx)
    fwalx.close()
    fwalx = open(Config.USERS_FILE)
    walletx = json.load(fwalx)
    fwalx.close()
    userid = update.effective_user.id
    WALLET_TEXT = f"Your moeny in wallet is: *{walletx[str(userid)]['usd']}$*\n\nTo add money to your wallet please send the amount you want to add: minimum 100$\nNote: Add a $ symbol at last(example: 1000$)"
    update.message.reply_text(WALLET_TEXT, parse_mode=ParseMode.MARKDOWN)


def waladd(bot: Bot, update: Update):
    try:
        moni = update.message.text
        userid = update.effective_user.id
        intmoni = moni.strip("$")
        monn = int(intmoni)
        if monn and "$" in moni:
            if monn >= Config.MIN_DEPOSIT:
                update.message.reply_text("Please wait initializing transaction!", parse_mode=ParseMode.MARKDOWN)
                topay = CoinPaymentsAPI().create_transaction(amount = monn, buyer_email = "kappalol@gmail.com", currency1 = "USD", currency2 = "BTC")
                if topay['error'] == "ok":
                    paymsg = f"Please send exactly ```{topay['result']['amount']}``` BTC on the address\n```{topay['result']['address']}```\nwithin 6 hrs! dont use cashapp since you cant send exact BTC amount\nif not sent exact amount it will be considered donation and your account will not be credited!\n\nIf you have sent the funds please wait for confirmation!"
                    update.message.reply_text(paymsg, parse_mode=ParseMode.MARKDOWN)
                    try:
                        threading.Thread(target=whiletrue, args = (topay, userid, update, monn, )).start()
                    except Exception as e:
                        LOGGER.error(e)
                else:
                    update.message.reply_text("Something is wrong with paymnet gateway, please try again!", parse_mode=ParseMode.MARKDOWN)
            else:
                update.message.reply_text(f"Watchout! the minimum deposit is {Config.MIN_DEPOSIT}$, please don't try to add less than that!", parse_mode=ParseMode.MARKDOWN)
    except Exception as e:
        LOGGER.error(e)
        pass

def whiletrue(topay, userid, update, monn):
    fwalx = open(Config.USERS_FILE)
    walletx = json.load(fwalx)
    fwalx.close()
    while True:
        try:
            sts = CoinPaymentsAPI().get_tx_info(txid = topay['result']['txn_id'])
            LOGGER.error(topay['result']['txn_id'])
            if sts['error'] == "ok":
                if sts['result']['status'] == 100:
                    if sts['result']['amountf'] <= sts['result']['receivedf']:
                        fwalx = open(Config.USERS_FILE)
                        walletx = json.load(fwalx)
                        fwalx.close()
                        with open(Config.USERS_FILE, "r+") as wfilex:
                            usd = walletx[str(userid)]['usd']
                            walletx[str(userid)]['usd'] = usd + monn
                            json.dump(walletx, wfilex, indent=4)
                            wfilex.close()
                            fwalx = open(Config.USERS_FILE)
                            walletx = json.load(fwalx)
                            fwalx.close()
                        update.message.reply_text(f"Added {monn}$ successfully, please check your wallet!", parse_mode=ParseMode.MARKDOWN)
                        break
                    else:
                        update.message.reply_text(f"You have sent less amount than that of funding amount,\nas said earlier it will be counted for donation,\ncontact admin for further queries @{Config.OWNER_USERNAME}", parse_mode=ParseMode.MARKDOWN)
                        break
                elif sts['result']['status'] == -1:
                    update.message.reply_text("Your transaction waiting time is up, Please try to deposit again!", parse_mode=ParseMode.MARKDOWN)
                    break
                else:
                    time.sleep(1050)
            else:
                update.message.reply_text("Something is wrong with paymnet gateway, if you have already sent the funds, contact admin to verify!", parse_mode=ParseMode.MARKDOWN)
                break
        except Exception as e:
            update.message.reply_text("Something is wrong with paymnet gateway, if you have already sent the funds, contact admin to verify!", parse_mode=ParseMode.MARKDOWN)
            LOGGER.error(e)
            break

__mod_name__ = "wallet"

dispatcher.add_handler(MessageHandler(Filters.regex('Wallet 💸') & ~Filters.command, wallet))
WALLET_HANDLER = CommandHandler("wallet", wallet)
dispatcher.add_handler(MessageHandler(Filters.regex('^\d+\$') & ~Filters.command, waladd))
dispatcher.add_handler(WALLET_HANDLER)